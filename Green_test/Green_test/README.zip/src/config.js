//export const BASE = 'http://172.16.182.16:8080/RCMPortal/api/v1';
//export const BASE = 'https://noncbsuat.bankofbaroda.co.in/qms-admin/api/v1/qmsAdmin';

export const BASE = 'https://noncbsuat.bankofbaroda.co.in/RCMPortal/api/v1';