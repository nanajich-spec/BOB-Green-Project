import React,{useState} from 'react';
import './Login.css';
import { useNavigate } from 'react-router-dom';
import logo from './bob_logo.png';
//import backgroundimage from './img4.jpeg';
import axiosIns from './axios';
// import {FontAwesomeIcon} from "@fortawesome/react-fontsome";
// import {faUser, faLock} from "fortawesome/free-solid-svg-icons";



const Login  = () => {

  const [userid, setUserid] = useState('');
  const [password, setPassword] = useState('');
  //const [userRole, setUserRole] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  const handleUseridChange = (e) => {
    const value = e.target.value;
    if (value.length <= 8) {
        setUserid(value);
    }
};

const handleClear = () => {
  return new Promise((resolve) => {
     
          setUserid('');
          setPassword('');
          resolve();
     
  });
  
};

const handleSubmit = (e) => {
  e.preventDefault();

  // const details =
  //   {
  //     userId: userid.toUpperCase(),
  //     cred: password,
           
  //   }
  // ;
      
  // try {

  //    console.log("data:", userid);
  //       axiosIns.post('/login', details).then(response => {
  //         console.log("Api response",response.data);
  //          window.sessionStorage.setItem("userDet", JSON.stringify({ 'userId': userid.toUpperCase(), 'userRole':response.data.userRole, 'zone': response.data.zone}));
          
  //          handleClear();
  //         alert("Login successful");
  //     //alert("user Role: " + response.data.userRole);
         
  //         if(response.data.userRole === "MAKER"){
  //             navigate('/maker');
  //         }else if(response.data.userRole === "CHECKER"){
  //           navigate('/checker');
  //         }else if(response.data.userRole === "CIAD"){
  //           navigate('/ciad');
  //         }


          
  //     }
  //   ).catch(error => {
  //         console.log(error);
  //         alert('Please enter correct information.');
  //         handleClear();
  //     }
  //     );;
  // }
  // catch (error) {
  //     console.log(error);
      
      
  // }
    

  navigate('/maker');

};

const handleMake = (e) => {
  e.preventDefault();
  const userRole = 'Maker';

  window.sessionStorage.setItem("userDet", JSON.stringify({  "userRole":"Maker"}));
  const userDet = JSON.parse(window.sessionStorage.getItem("userDet"));
  const userRoleP= userDet.userRole;
  console.log("User Role:" , userRoleP);
   navigate('/Maker');

};

const handleCheck = (e) => {
  e.preventDefault();
  window.sessionStorage.setItem("userDet", JSON.stringify({  "userRole":"Checker"}));
  const userDet = JSON.parse(window.sessionStorage.getItem("userDet"));
  const userRoleP= userDet.userRole;
  console.log("User Role:" , userRoleP);
  navigate('/verify');

};

const handleAdmin = (e) => {
  e.preventDefault();
  window.sessionStorage.setItem("userDet", JSON.stringify({ 'userRole':"Admin"}));
  navigate('/admin');

};






  return (
    <div className="Anime">
      {/* <div className="total"> */}
      <div className="login-container">
      
      
            <div className="logo-container">
                  <img src={logo} alt="Logo" className="logo" />
            </div> 
            <div className="login-form">
            <h1 className="title">Green Project Portal</h1>
            {/* <div className="line-container">
                      
              <div className="line"></div>
            </div> */}
            {/* <h2>Login</h2> */}
            
                    <div className="input-group1">
                        <label htmlFor="userid">DOMAIN ID</label>
                        
                        <input
                            type="text"
                            id="userid"
                            value={userid.toUpperCase()}
                         
                          //onChange={(e) => setUserid(e.target.value)}
                            placeholder="Enter your Domain id"
                            required
                            onChange={handleUseridChange}
                            maxLength="8" />
                        {submitted && userid.length !== 8 && <small className="p-error">Please enter correct userid.</small>}

                    </div>
                    <div className="input-group1">
                        <label htmlFor="password">PASSWORD</label>
                        <input
                            type="password"
                            id="password"
                           
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            placeholder="Enter your Password"
                            required />
                    </div>
                    <div className='button-container1'>

                        {/* <button className="button1" onClick={handleSubmit}>Login </button> */}
                        <button className="button1" onClick={handleMake}>Login Maker</button>
                        <button className="button1" onClick={handleCheck}>Login Checker</button>
                        <button className="button1" onClick={handleAdmin}>Login Admin</button>
                        {/* <button className="button1" onClick={handleSubmit1}>Login Checker</button> */}


                        {/* <button className="button1" onClick={handleCIAD}>Login CIAD</button> */}
                        {/* <button className="button1" onClick={handleSubmit2}>Login CIAD</button> */}

                    </div>
                    <p>Copyright &copy; 2024 Bank of Baroda. All rights reserved.</p>
      </div>
      {/* <div className="image">
                    <img src={backgroundimage} alt="backgroundimage" className="backgroundimage" />
      </div>
      </div> */}
    </div>
    </div>
  

  );
}

export default Login;
