import React, { useEffect, useState } from 'react';
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import axios from "axios";
import './Admin.css';
import Header from './Header.js';
import Sidebar from './Sidebar.js';
import './Header.css';
import './Sidebar.css';
import { useNavigate, useLocation } from 'react-router-dom';
import logo2 from './R-logo.png';
import axiosIns from './axios';
import {BASE} from './config';

const Admin_c = () => {

    const [accounts, setAccounts] = useState([]);
    const [selectedAccount, setSelectedAccount] = useState(null);
    const [globalFilter, setGlobalFilter] = useState("");
    const navigate = useNavigate();
    const location = useLocation();
    const [userId, setUserId] = useState(null);

    useEffect(() => {

        const fetchAccounts = async () => {
            try {
              // Assuming the backend API returns accounts created by the maker

              const response = await axios.get(`https://noncbsuat.bankofbaroda.co.in/green-project/api/v1/ViewDetailsAdmin`)
              // console.log(response);
              console.log("Fetched Accounts:", response.data);
              if (response.status === 200) {
              setAccounts(response.data);
              // Set the data to state
            }} catch (error) {
              console.error("Error fetching accounts:", error);
            }
          };

          fetchAccounts();
        }, []);





        const handleRowClick = async (rowData) => {
            // Extract account number from clicked row
             try {
                const accountNumber = rowData.accountNumber;
                const response = await axios.get(`https://noncbsuat.bankofbaroda.co.in/green-project/api/v1/${accountNumber}`);
                //  const response = await axios.get(`https://noncbsuat.bankofbaroda.co.in/green-project/api/v1/"/admin/${accountNumber}`);
                // console.log(response.data);

              console.log("Fetched Account Details:", response.data);
              if (response.status === 200 && response.data) {
              navigate("/admin2", { state: { accountNumber: accountNumber } }); // ✅ Pass API response to next page
              }
                 //  navigate(`/Middle`, { state: response.data });

             } catch (error) {
               console.error("Error fetching account details:", error);
             }
             console.log("Row clicked:",rowData);
           };
        
        



    return (

        <div className="container1">
            <Header/>
            <Sidebar/>
            <div className="checker-container">


      <div className="table-containerr">

        <DataTable
          value={accounts}
          selectionMode="single"

          onRowSelect={(event)=>handleRowClick(event.data)}

          //ch
          // onRowSelect={(event) => {
          //   const accountNumber = event.data.accountNumber;
          //   axios.get(`http://172.16.182.177.8080/green-project/api/v1/${accountNumber}`).then((response) => 
          //   {console.log("fetched account details:",response.data);
          //     if(response.status === 200 && response.data){
          //       navigate(`/Admin2/${accountNumber}`,{state: response.data});
          //     }
          //   })
          //   .catch((error) => {
          //     console.error("Error fetching Account details:",error);
          //   });
          // }}

          dataKey="accountNumber"
          paginator
          rows={10}
          rowsPerPageOptions={[5, 10, 25]}
          paginatorTemplate="FirstPageLink PrevPageLink PageLinks NextPageLink LastPageLink CurrentPageReport RowsPerPageDropdown"
          currentPageReportTemplate="Showing {first} to {last} of {totalRecords} Accounts"
          globalFilter={globalFilter}
        >
          <Column header="S.No" body={(rowData, { rowIndex }) => rowIndex + 1} style={{ minWidth: "2rem" }} />
          <Column field="accountNumber" header="Account Number" sortable style={{ minWidth: "4rem" }} />
          <Column field="borrowerName" header="BorrowerName" sortable style={{ minWidth: "4rem" }} />
          <Column field="status" header="Status" sortable style={{ minWidth: "4rem" }} />
          {/* <Column body={actionTemplate} style={{ minWidth: "8rem" }} /> */}
        </DataTable>
      </div>


      </div>


        </div>
    );
};

export default Admin_c;