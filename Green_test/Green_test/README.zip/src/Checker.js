
import React, { useState ,useEffect } from "react";
// import { Button } from "primereact/button";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import Header from './Header';
import Sidebar from './Sidebar';
import "./Checker.css";
import { useLocation } from "react-router-dom";



const Checker = () => {
  const [accounts, setAccounts] = useState([]);
  const [filteredAccounts,setFilteredAccounts]= useState([]);//ch
  //const [filterType, setFilterType]= useState("");//ch
  const [selectedAccount, setSelectedAccount] = useState(null);
  const [globalFilter, setGlobalFilter] = useState("");
  const navigate = useNavigate();
    const location = useLocation();
  // Fetch accounts added by the maker



  useEffect(() => {
    const fetchAccounts = async () => {
      try {
        // Assuming the backend API returns accounts created by the maker

        const response = await axios.get(`https://noncbsuat.bankofbaroda.co.in/green-project/api/v1/ViewDetails`)
        // console.log(response);
        console.log("Fetched Accounts:", response.data);
        if (response.status === 200) {
        setAccounts(response.data);
        setFilteredAccounts(response.data);//ch
        // Set the data to state
        
      }} catch (error) {
        console.error("Error fetching accounts:", error);
      }
    };

    fetchAccounts();
  }, []);

 


  const handleRowClick = async (rowData) => {
   // Extract account number from clicked row
    try {
      const accountNumber = rowData.accountNumber;
      const response = await axios.get(`https://noncbsuat.bankofbaroda.co.in/green-project/api/v1/${accountNumber}`);
      // console.log(response.data);

      console.log("Fetched Account Details:", response.data);
      if (response.status === 200 && response.data) {
      navigate("/Checker1", { state: { accountNumber: accountNumber } }); // ✅ Pass API response to next page
      }
        //  navigate(`/Middle`, { state: response.data });

      } catch (error) {
      console.error("Error fetching account details:", error);
      }
    };
  
  //ch
  const handleFilterChange=(status)=>{
    const filtered =accounts.filter(account => account.status === status);
    setFilteredAccounts(filtered);
  }

  return (
    <div className="checker-container">
      <Header />
      <Sidebar onFilterChange={handleFilterChange} /> 
      <div className="table-containerr">
   
        <DataTable
          //value={accounts}
          value={filteredAccounts}//ch
          selectionMode="single"

            onRowSelect={(event)=>handleRowClick(event.data)}

          dataKey="accountNumber"
          paginator
          rows={10}
          rowsPerPageOptions={[5, 10, 25]}
          paginatorTemplate="FirstPageLink PrevPageLink PageLinks NextPageLink LastPageLink CurrentPageReport RowsPerPageDropdown"
          currentPageReportTemplate="Showing {first} to {last} of {totalRecords} Accounts"
          globalFilter={globalFilter}
        >
          <Column header="S.No" body={(rowData, { rowIndex }) => rowIndex + 1} style={{ minWidth: "2rem" }} />
          <Column field="accountNumber" header="Account Number" sortable style={{ minWidth: "4rem" }} />
          <Column field="borrowerName" header="BorrowerName" sortable style={{ minWidth: "4rem" }} />
          <Column field="status" header="Status" sortable style={{ minWidth: "4rem" }} />
          {/* <Column body={actionTemplate} style={{ minWidth: "8rem" }} /> */}
        </DataTable>
      </div>
    </div>
  );
};

export default Checker;




// import React, { useState, useEffect } from "react";
// import { DataTable } from "primereact/datatable";
// import { Column } from "primereact/column";
// import { useNavigate } from "react-router-dom";
// import axios from "axios";
// import Header from './Header';
// import Sidebar from './Sidebar';
// import "./Checker.css";
 
// const Checker = () => {
//   const [accounts, setAccounts] = useState([]);
//   const [selectedAccount, setSelectedAccount] = useState(null);
//   const [globalFilter, setGlobalFilter] = useState("");
//   const [selectedTab, setSelectedTab] = useState("pending"); // ✅ Default: Pending
//   const navigate = useNavigate();
 
//   // Fetch accounts added by the maker
//   useEffect(() => {
//     const fetchAccounts = async () => {
//       try {
//         const response = await axios.get(`https://noncbsuat.bankofbaroda.co.in/green-project/api/v1/ViewDetails`);
//         console.log("Fetched Accounts:", response.data);
//         if (response.status === 200) {
//           setAccounts(response.data);
//         }
//       } catch (error) {
//         console.error("Error fetching accounts:", error);
//       }
//     };
//     fetchAccounts();
//   }, []);
 
//   // ✅ Filter accounts based on selected tab
//   const filteredAccounts = accounts.filter(account =>
//     selectedTab === "pending" ? account.status === "PENDING" : account.status === "VERIFIED"
//   );
 
//   // ✅ Handle row click
//   const handleRowClick = async (rowData) => {
//     try {
//       const accountNumber = rowData.accountNumber;
//       const response = await axios.get(`https://noncbsuat.bankofbaroda.co.in/green-project/api/v1/${accountNumber}`);
//       console.log("Fetched Account Details:", response.data);
//       if (response.status === 200 && response.data) {
//         navigate("/Checker1", { state: { accountNumber: accountNumber } });
//       }
//     } catch (error) {
//       console.error("Error fetching account details:", error);
//     }
//   };
 
//   return (
//     <div className="checker-container">
//       <Header />
//       <Sidebar />
//       <div className="table-containerr">
        
//         {/* ✅ Toggle Between Pending & Verified */}
//         <div className="tab-buttons">
//           <button 
//             className={selectedTab === "pending" ? "active-tab" : ""}
//             onClick={() => setSelectedTab("pending")}
//           >
//             Pending
//           </button>
//           <button 
//             className={selectedTab === "verified" ? "active-tab" : ""}
//             onClick={() => setSelectedTab("verified")}
//           >
//             Verified
//           </button>
//         </div>
 
//         {/* ✅ DataTable for Pending & Verified Accounts */}
//         <DataTable
//           value={filteredAccounts}
//           selectionMode="single"
//           onRowSelect={(event) => handleRowClick(event.data)}
//           dataKey="accountNumber"
//           paginator
//           rows={10}
//           rowsPerPageOptions={[5, 10, 25]}
//           paginatorTemplate="FirstPageLink PrevPageLink PageLinks NextPageLink LastPageLink CurrentPageReport RowsPerPageDropdown"
//           currentPageReportTemplate="Showing {first} to {last} of {totalRecords} Accounts"
//           globalFilter={globalFilter}
//         >
//           <Column header="S.No" body={(rowData, { rowIndex }) => rowIndex + 1} style={{ minWidth: "2rem" }} />
//           <Column field="accountNumber" header="Account Number" sortable style={{ minWidth: "4rem" }} />
//           <Column field="borrowerName" header="Borrower Name" sortable style={{ minWidth: "4rem" }} />
//           <Column field="status" header="Status" sortable style={{ minWidth: "4rem" }} />
//         </DataTable>
//       </div>
//     </div>
//   );
// };
 
// export default Checker;
 



