import React from 'react';
import { BrowserRouter, Routes, Route} from 'react-router-dom';
import logo from './logo.svg';
import './App.css';
import ExistingRecordsPage from './ExistingRecordsPage';
import RiskAssessment from './RiskAssessment.js';
import ProjectSpecificIndicator from './ProjectSpecificIndicator.js';
import Login from './Login.js';
// import Dashboard from './Dashboard.js';
import Datatable from './DataTable';
import DataTable1 from './DataTable1';
import Maker from './Maker.js';

import Checker from './Checker.js';
import Checker1 from './Checker1.js'
import Verified from './Verified.js';
//  import Middle from './Middle.js';
import Admin from './Admin.js';
import Admin1 from './Admin1.js';
import Admin2 from './Admin2.js';
import Admin_c from './Admin_c.js';
import PDFDocument from './PDFDocument.js';
import PDFDocumentUser from './PDFDocument.js';


function App() {
  return (
    <div className="App">
      <BrowserRouter basename='/greenproj'>



        {/* <footer className="footer">
          <p>Copyright &copy; 2024 Bank of Baroda. All rights reserved.</p>
        </footer> */}




        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/existingrecords" element={<ExistingRecordsPage />} />
          <Route path="/datatable" element={<Datatable />} />
          <Route path="/returnfromadmin" element={<DataTable1 />} />
          <Route path="/Maker" element={<Maker/>} />
          <Route path="/checker" element={<Checker />} />
          <Route path="/checker1" element={<Checker1 />} />
          <Route path="/Verified" element={<Verified />} />
          <Route path="/RiskAssessment" element={<RiskAssessment />} />
          <Route path="/ProjectSpecificIndicator" element={<ProjectSpecificIndicator />} />
          <Route path="/verify" element={<Checker />} />
          <Route path="/admin" element={<Admin />} />
          <Route path="/admin1" element={<Admin1 />} />
          <Route path="/admin2" element={<Admin2 />} />
          <Route path="/*" element={<Login />} />
          <Route path='/report' element={<Admin_c/>}/>
          <Route path='/admin/:accountNumber' element={<Admin/>}/>   {/*sr */}
          <Route path='/pdfdownload/:accountNumber' element={<PDFDocument/>}/>
          

          
          
          
         
        </Routes>

          {/* <Table/> */}
          {/* <Maker /> */}
          {/* <Login /> */}
          {/* <CheckerD /> */}
          {/* <CiadD /> */}
      </BrowserRouter>
      
    </div>
  );
}

export default App;
