import axios from 'axios';

//const BASE = 'http://172.16.182.16:8080/RCMPortal/api/v1';
const BASE = 'https://noncbsuat.bankofbaroda.co.in/RCMPortal/api/v1';
//const BASE = 'http://localhost:8070/illproject';
const axiosIns = axios.create({
    baseURL: BASE,
});

export default axiosIns;