// import React, { useState } from 'react';
// import { Button } from 'primereact/button';
// import { useNavigate } from 'react-router-dom';
// import './RiskAssessment.css'; // Ensure you have styling for the component
// import Header from './Header.js';
// import Sidebar from './Sidebar.js';
 
// import './Header.css';
// import './Sidebar.css';
 
// const RiskAssessment = () => {
//   const [locationVulnerability, setLocationVulnerability] = useState('');
//   const [seaLevelRise, setSeaLevelRise] = useState('');
//   const [supplyChainDisruptions, setSupplyChainDisruptions] = useState('');
//   const [carbonIntensiveSector, setCarbonIntensiveSector] = useState('');
//   const [strandedAssetsRisk, setStrandedAssetsRisk] = useState('');
//   const [shiftingConsumerPreferences, setShiftingConsumerPreferences] = useState('');
//   const [businessContinuityPlans, setBusinessContinuityPlans] = useState('');
//   const [climateResilienceInfrastructure, setClimateResilienceInfrastructure] = useState('');
//   const [emissionFootprint, setEmissionFootprint] = useState('');
//   const [submitted, setSubmitted] = useState(false);
//   const navigate = useNavigate();
 
//   // Handle save button click
//   const handleSave = () => {
//     setSubmitted(true); // Trigger validation
 
//     // Validation logic for required fields
//     if (!locationVulnerability || !seaLevelRise || !supplyChainDisruptions ||
//         !carbonIntensiveSector || !strandedAssetsRisk || !shiftingConsumerPreferences ||
//         !businessContinuityPlans || !climateResilienceInfrastructure || !emissionFootprint) {
//       return; // Do not submit if validation fails
//     }
 
//     console.log({
//       locationVulnerability,
//       seaLevelRise,
//       supplyChainDisruptions,
//       carbonIntensiveSector,
//       strandedAssetsRisk,
//       shiftingConsumerPreferences,
//       businessContinuityPlans,
//       climateResilienceInfrastructure,
//       emissionFootprint,
//     });
 
//     // Navigate to the next page or handle backend logic
//     navigate('/NextStep'); // Replace with the next route
//   };
 
//   return (
// <div className="container1">
// <Header />
// <h1 className="title2">BoB Green Finance Portal</h1>
// <div className="line-container1">
// <div className="line1"></div>
// </div>
// <Sidebar />
// <div className="business-div">
// <h2 className="business-title">Risk Assessment Criteria (To be filled by the Bank)</h2>
 
//         <div className="vertical">
// <div className="vertical1">
// <div className="form-group2">
// <label htmlFor="locationVulnerability">Location Vulnerability<span className="required-star">*</span> :</label>
// <input
//                 id="locationVulnerability"
//                 type="text"
//                 value={locationVulnerability}
//                 onChange={(e) => setLocationVulnerability(e.target.value)}
//                 className={submitted && !locationVulnerability ? 'error' : ''}
//                 required
//               />
// </div>
 
//             <div className="form-group2">
// <label htmlFor="seaLevelRise">Sea-level Rise (Coastal Properties Only)<span className="required-star">*</span> :</label>
// <input
//                 id="seaLevelRise"
//                 type="text"
//                 value={seaLevelRise}
//                 onChange={(e) => setSeaLevelRise(e.target.value)}
//                 className={submitted && !seaLevelRise ? 'error' : ''}
//                 required
//               />
// </div>
 
//             <div className="form-group2">
// <label htmlFor="supplyChainDisruptions">Supply Chain Disruptions<span className="required-star">*</span> :</label>
// <input
//                 id="supplyChainDisruptions"
//                 type="text"
//                 value={supplyChainDisruptions}
//                 onChange={(e) => setSupplyChainDisruptions(e.target.value)}
//                 className={submitted && !supplyChainDisruptions ? 'error' : ''}
//                 required
//               />
// </div>
// </div>
 
//           <div className="vertical2">
// <div className="form-group2">
// <label htmlFor="carbonIntensiveSector">Carbon-Intensive Sector<span className="required-star">*</span> :</label>
// <input
//                 id="carbonIntensiveSector"
//                 type="text"
//                 value={carbonIntensiveSector}
//                 onChange={(e) => setCarbonIntensiveSector(e.target.value)}
//                 className={submitted && !carbonIntensiveSector ? 'error' : ''}
//                 required
//               />
// </div>
 
//             <div className="form-group2">
// <label htmlFor="strandedAssetsRisk">Stranded Assets Risk<span className="required-star">*</span> :</label>
// <input
//                 id="strandedAssetsRisk"
//                 type="text"
//                 value={strandedAssetsRisk}
//                 onChange={(e) => setStrandedAssetsRisk(e.target.value)}
//                 className={submitted && !strandedAssetsRisk ? 'error' : ''}
//                 required
//               />
// </div>
 
//             <div className="form-group2">
// <label htmlFor="shiftingConsumerPreferences">Shifting Consumer Preferences<span className="required-star">*</span> :</label>
// <input
//                 id="shiftingConsumerPreferences"
//                 type="text"
//                 value={shiftingConsumerPreferences}
//                 onChange={(e) => setShiftingConsumerPreferences(e.target.value)}
//                 className={submitted && !shiftingConsumerPreferences ? 'error' : ''}
//                 required
//               />
// </div>
// </div>
// </div>
 
//         <div className="vertical">
// <div className="vertical1">
// <div className="form-group2">
// <label htmlFor="businessContinuityPlans">Business Continuity Plans<span className="required-star">*</span> :</label>
// <input
//                 id="businessContinuityPlans"
//                 type="text"
//                 value={businessContinuityPlans}
//                 onChange={(e) => setBusinessContinuityPlans(e.target.value)}
//                 className={submitted && !businessContinuityPlans ? 'error' : ''}
//                 required
//               />
// </div>
 
//             <div className="form-group2">
// <label htmlFor="climateResilienceInfrastructure">Climate Resilience Infrastructure<span className="required-star">*</span> :</label>
// <input
//                 id="climateResilienceInfrastructure"
//                 type="text"
//                 value={climateResilienceInfrastructure}
//                 onChange={(e) => setClimateResilienceInfrastructure(e.target.value)}
//                 className={submitted && !climateResilienceInfrastructure ? 'error' : ''}
//                 required
//               />
// </div>
// </div>
 
//           <div className="vertical2">
// <div className="form-group2">
// <label htmlFor="emissionFootprint">Borrower’s Emission Footprint<span className="required-star">*</span> :</label>
// <input
//                 id="emissionFootprint"
//                 type="text"
//                 value={emissionFootprint}
//                 onChange={(e) => setEmissionFootprint(e.target.value)}
//                 className={submitted && !emissionFootprint ? 'error' : ''}
//                 required
//               />
// </div>
// </div>
// </div>
 
//         {/* Save & Next Button */}
// <div className="button-container2">
// <Button label="Save & Next" className="saveNext" onClick={handleSave} />
// </div>
// </div>
// </div>
//   );
// };
 
// export default RiskAssessment;








import React, { useState } from 'react';
import { Button } from 'primereact/button';
import { useNavigate } from 'react-router-dom';
import './RiskAssessment.css'; // Ensure you have styling for the component
import Header from './Header.js';
import Sidebar from './Sidebar.js';
 
import './Header.css';
import './Sidebar.css';
// import axios from 'axios';//added new step
 
const RiskAssessment = () => {
  const [physicalRisk, setPhysicalRisk] = useState({
    locationVulnerability: '',
    seaLevelRise: '',
    supplyChainDisruptions: '',
  });
 
  const [transitionRisk, setTransitionRisk] = useState({
    carbonIntensiveSector: '',
    strandedAssetsRisk: '',
    shiftingConsumerPreferences: '',
  });
 
  const [operationalVulnerabilities, setOperationalVulnerabilities] = useState({
    businessContinuityPlans: '',
    climateResilienceInfrastructure: '',
  });
 
  const [emissionData, setEmissionData] = useState({
    borrowersEmissionFootprint: '',
  });
 
  const [submitted, setSubmitted] = useState(false);
  const navigate = useNavigate();
 
  // Handle Save Button Click
  const handleSave = async () => {   //here only async word added
    setSubmitted(true); // Trigger validation

//     const formData = new FormData();
//     formData.set('physicalRisk', JSON.stringify(physicalRisk));
//     formData.set('transitionRisk', JSON.stringify(transitionRisk));
//     formData.set('operationalVulnerabilities', JSON.stringify(operationalVulnerabilities));
//     formData.set('emissionData', JSON.stringify(emissionData));
 
//     try {
// const response = await axios.post('http://localhost:8080/api/risk-assessment', formData, {
//         headers: {
//           'Content-Type': 'multipart/form-data',
//         },
//       });
 
//       if (response.status === 200) {
//         console.log('Data saved successfully:', response.data);
//         navigate('/ProjectSpecificIndicator');
//        } else {
//          console.error('Failed to save data');
//       }
//      } catch (error) {
//       console.error('Error saving data:', error);
//      }
  
//    };

 
    // Validate required fields
    // if (
    //   !physicalRisk.locationVulnerability ||
    //   !physicalRisk.seaLevelRise ||
    //   !physicalRisk.supplyChainDisruptions ||
    //   !transitionRisk.carbonIntensiveSector ||
    //   !transitionRisk.strandedAssetsRisk ||
    //   !transitionRisk.shiftingConsumerPreferences ||
    //   !operationalVulnerabilities.businessContinuityPlans ||
    //   !operationalVulnerabilities.climateResilienceInfrastructure ||
    //   !emissionData.borrowersEmissionFootprint
    // ) {
    //   return; // Do not submit if validation fails
    // }
 
    console.log({
      PhysicalRisk: physicalRisk,
      TransitionRisk: transitionRisk,
      OperationalVulnerabilities: operationalVulnerabilities,
      EmissionData: emissionData,
    });
 
    // Navigate to the next page
    navigate('/ProjectSpecificIndicator'); // Replace with actual route
  };
 
  
  const handleBack = () => {
    navigate(-1);
};

  return (
    <div className="container1">
      <Header />
      <h1 className="title2">BoB Green Finance Portal</h1>
      <div className="line-container1">
        <div className="line1"></div>
      </div>
      <Sidebar />
 
      <div className="business-div">
        <h2 className="business-title">Risk Assessment Criteria (To be filled by the Bank)</h2>
       
        {/* Physical Risk Section */}
        <div className="risk-container">
        <div className="risk-section">
          <h3 className="risk-category">Physical Risk</h3>
          
          <div className="form-group">
            <label>Location Vulnerability<span className="required-star">*</span> :</label>
            <textarea
              value={physicalRisk.locationVulnerability}
              onChange={(e) => setPhysicalRisk({ ...physicalRisk, locationVulnerability: e.target.value })}
              className={submitted && !physicalRisk.locationVulnerability ? 'error' : ''}
              required
            />
          </div>
 
          <div className="form-group">
            <label>Sea-Level Rise (Coastal Properties Only)<span className="required-star">*</span> :</label>
            <textarea
              value={physicalRisk.seaLevelRise}
              onChange={(e) => setPhysicalRisk({ ...physicalRisk, seaLevelRise: e.target.value })}
              className={submitted && !physicalRisk.seaLevelRise ? 'error' : ''}
              required
            />
          </div>
 
          <div className="form-group">
            <label>Supply Chain Disruptions<span className="required-star">*</span> :</label>
            <textarea
              value={physicalRisk.supplyChainDisruptions}
              onChange={(e) => setPhysicalRisk({ ...physicalRisk, supplyChainDisruptions: e.target.value })}
              className={submitted && !physicalRisk.supplyChainDisruptions ? 'error' : ''}
              required
            />
          </div>
        </div>
 
        {/* Transition Risk Section */}
        <div className="risk-section">
          <h3 className="risk-category">Transition Risk</h3>
 
          <div className="form-group">
            <label>Carbon-Intensive Sector<span className="required-star">*</span> :</label>
            <textarea
              value={transitionRisk.carbonIntensiveSector}
              onChange={(e) => setTransitionRisk({ ...transitionRisk, carbonIntensiveSector: e.target.value })}
              className={submitted && !transitionRisk.carbonIntensiveSector ? 'error' : ''}
              required
            />
          </div>
 
          <div className="form-group">
            <label>Stranded Assets Risk<span className="required-star">*</span> :</label>
            <textarea
              value={transitionRisk.strandedAssetsRisk}
              onChange={(e) => setTransitionRisk({ ...transitionRisk, strandedAssetsRisk: e.target.value })}
              className={submitted && !transitionRisk.strandedAssetsRisk ? 'error' : ''}
              required
            />
          </div>
 
          <div className="form-group">
            <label>Shifting Consumer Preferences<span className="required-star">*</span> :</label>
            <textarea
              value={transitionRisk.shiftingConsumerPreferences}
              onChange={(e) => setTransitionRisk({ ...transitionRisk, shiftingConsumerPreferences: e.target.value })}
              className={submitted && !transitionRisk.shiftingConsumerPreferences ? 'error' : ''}
              required
            />
          </div>
        </div>
 </div>
        {/* Operational Vulnerabilities Section */}
        <div className="risk-container">
        <div className="risk-section">
          <h3 className="risk-category">Operational Vulnerabilities</h3>
 
          <div className="form-group">
            <label>Business Continuity Plans<span className="required-star">*</span> :</label>
            <textarea
              value={operationalVulnerabilities.businessContinuityPlans}
              onChange={(e) => setOperationalVulnerabilities({ ...operationalVulnerabilities, businessContinuityPlans: e.target.value })}
              className={submitted && !operationalVulnerabilities.businessContinuityPlans ? 'error' : ''}
              required
            />
          </div>
 
          <div className="form-group">
            <label>Climate Resilience Infrastructure<span className="required-star">*</span> :</label>
            <textarea
              value={operationalVulnerabilities.climateResilienceInfrastructure}
              onChange={(e) => setOperationalVulnerabilities({ ...operationalVulnerabilities, climateResilienceInfrastructure: e.target.value })}
              className={submitted && !operationalVulnerabilities.climateResilienceInfrastructure ? 'error' : ''}
              required
            />
          </div>
        </div>
 
        {/* Emission Data Section */}
        <div className="risk-section">
          <h3 className="risk-category">Emission Data</h3>
 
          <div className="form-group">
            <label>Borrower’s Emission Footprint<span className="required-star">*</span> :</label>
            <textarea
              value={emissionData.borrowersEmissionFootprint}
              onChange={(e) => setEmissionData({ ...emissionData, borrowersEmissionFootprint: e.target.value })}
              className={submitted && !emissionData.borrowersEmissionFootprint ? 'error' : ''}
              required
            />
          </div>
        </div>
        </div>
        </div>
        {/* Save & Next Button */}
        <div className="button-container2">
          <Button label="Save & Next" className="saveNext" onClick={handleSave} />
        </div>
        <div className='button-container3'> 
                <Button label="Back" className="backButton" onClick={handleBack} />
            </div>
     
    </div>
  );
};
 
export default RiskAssessment;
