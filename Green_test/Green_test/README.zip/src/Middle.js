import React, {  useState ,useEffect } from 'react';
import { Button } from 'primereact/button';
import './Maker.css';
import { Dropdown } from "primereact/dropdown";
import {  userRole, handleApprovalStatus } from './ProjectSpecificIndicator.js';
import { Toast } from 'primereact/toast';
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import 'primereact/resources/themes/lara-light-indigo/theme.css';
import 'primereact/resources/primereact.min.css';
import Header from './Header.js';
import Sidebar from './Sidebar.js';
import axios from 'axios'
import {useRef} from'react';
import './Header.css';
import './Sidebar.css';
import { useParams } from "react-router-dom";
import { } from 'react-router-dom';
 import './Middle.css';
 
const Middle = () => {
    const toast = useRef(null);
    const [formData, setFormData] = useState({
        generalInfo: {
          accountNumber: '',
          borrowerName: '',
          branchName: '',
          panNumber: '',
          cinNumber: '',
          schemeCode: '',
          activityCode: '',
          description: '',
          projName: '',
          sector: '',
          location: '',
          susobj: '',
          stakeEng: '',
          reportReq: '',
          timeline: '',
          budget: '',
          eiaComments: '',
          eiaFile: null,
          legalVerificationComments: '',
          legalVerificationFile:null,
          financialHealthComments: '',
          financialHealthFile:null,
          esgCompliance: '',
          esgFile: null,
        },
        riskAssessmentData:
          {
            vulnerability: '',
         vulnerabilityFlag: '',
        carbonintensive: '',
          carbonintFlag: '',
         sealevel:'',
        sealevelFlag: '',
       assetrisk: '',
     assestriskFlag: '',
    supplychain: '',
     supplychainFlag: '',
     shifting: '',
    shiftingFlag: '',
     business:'',
    businessFlag: '',
    climate: '',
      climateFlag: '',
    borroweremission: '',
    borrowermissionFlag: '',
},
     
  indicators:
  [{ indicator: "", description: "", comment: "", type: "", methodology: "" }],
  });
   
 
  // Stepper state
  const [activeIndex, setActiveIndex] = useState(0);
  const [selectedSUSObj, setSelectedSUSObj] = useState('');
  const [indicators, setIndicators] = useState();
  const [susobjs, setSusobjs] = useState([]);
  const [isLoading, setIsLoading ] = useState([false]);
  const [userRole,] = useState('');
  const [approvalStatus] = useState(null); // Define approvalStatus as state if needed
  const [file, setFile] = useState(null); // State to store the selected file
  const [remarks, setRemarks] = useState('');
  //  const[accountNumber,setAccountNumber]=useState('');
  const[fileName,setFileName]=useState('');
  const{accountNumber}=useParams();
  const [ setApprovalStatus] = useState(null);
  const [status, setStatus] = useState(""); // Track the selected status (Approve/Reject)
  const [comments, setComments] = useState("");
  const [isRejected, setIsRejected] = useState(false); // Flag to show comment box if rejected
  const [AccN, setAccN ] = useState ('');
  const [fieldStatus, setFieldStatus] = useState({});
 


  const generalInfo = {
    accountNumber: formData.generalInfo?.accountNumber,   // Account Number
    borrowerName: formData.generalInfo?.borrowerName,     // Borrower's Name
      borrowerFlag: formData.generalInfo?.borrowerFlag,     // Borrower Flag
    branchName: formData.generalInfo?.branchName,         // Branch Name
    branchFlag: formData.generalInfo?.branchFlag,         // Branch Flag
    panNumber: formData.generalInfo?.panNumber,           // PAN Number
  panFlag: formData.generalInfo?.panFlag,               // PAN Flag
    cinNumber: formData.generalInfo?.cinNumber,           // CIN Number
    cinFlag: formData.generalInfo?.cinFlag,               // CIN Flag
    schemeCode: formData.generalInfo?.schemeCode,         // Scheme Code
   schemeFlag: formData.generalInfo?.schemeFlag,         // Scheme Flag
    activityCode: formData.generalInfo?.activityCode,     // Activity Code
    activityFlag: formData.generalInfo?.activityFlag,     // Activity Flag
    projName: formData.generalInfo?.projName,             // Project Name
   projFlag: formData.generalInfo?.projFlag,             // Project Flag
    sector: formData.generalInfo?.sector,                 // Sector
 sectorFlag: formData.generalInfo?.sectorFlag,         // Sector Flag
    location: formData.generalInfo?.location,             // Location
    locationFlag: formData.generalInfo?.locationFlag,     // Location Flag
    description: formData.generalInfo?.description,       // Description
    descpFlag: formData.generalInfo?.descpFlag,           // Description Flag
    susobj: formData.generalInfo?.susobj,                 // Sustainable Objective
   susobjFlag: formData.generalInfo?.susobjFlag,         // Sustainable Objective Flag
    stakeEng: formData.generalInfo?.stakeEng,             // Stakeholder Engagement
   stakeEngFlag: formData.generalInfo?.stakeEngFlag,     // Stakeholder Engagement Flag
    reportReq: formData.generalInfo?.reportReq,           // Report Requirement
    reportReqFlag: formData.generalInfo?.reportReqFlag,   // Report Requirement Flag
    timeline: formData.generalInfo?.timeline,             // Timeline
   timelineFlag: formData.generalInfo?.timelineFlag,     // Timeline Flag
    budget: formData.generalInfo?.budget,                 // Budget
    budgetFlag: formData.generalInfo?.budgetFlag,         // Budget Flag
    legalVerificationComments: formData.generalInfo?.legalVerificationComments,  // Legal Verification Comments
   legalverFlag: formData.generalInfo?.legalverFlag,     // Legal Verification Flag
    financialHealthComments: formData.generalInfo?.financialHealthComments,      // Financial Health Comments
   financialHealthFlag: formData.generalInfo?.financialHealthFlag, // Financial Health Flag
    esgCompliance: formData.gerenalInfo?.esgCompliance,     // ESG Compliance
 esgCompFlag: formData.generalInfo?.esgCompFlag,         // ESG Compliance Flag
 
  };
  const riskAssessmentData ={
    vulnerability: formData.riskAssessmentData?.vulnerability,    
    carbonintensive: formData.riskAssessmentData?.carbonintensive,
    sealevel: formData.riskAssessmentData?.sealevel,              
    assetrisk: formData.riskAssessmentData?.assetrisk,           
    supplychain: formData.riskAssessmentData?.supplychain,        
    shifting: formData.riskAssessmentData?.shifting,              
    business: formData.riskAssessmentData?.business,              
    climate: formData.riskAssessmentData?.climate,                
    borroweremission: formData.riskAssessmentData?.borroweremission, 
  };


  
  const saveGeneralInfo = async (accountNum) => {
    console.log(generalInfo);
    try {
      console.log("inside general info");
      const response = await axios.post(
        `http://172.16.182.177:8091/green-project/api/v1/updatedPhase1/${accountNum}`,
        generalInfo,
        { headers: { "Content-Type": "application/json" ,
 
        } ,
      }
      );
      console.log(response);
      if (response.status === 200) {
        toast.current.show({ severity: 'success', summary: 'Success', detail: 'General info saved successfully!' });
      } else {
        throw new Error("Unexpected response from server");
      }
    } catch (error) {
      console.error("Error saving general info:", error);
      toast.current.show({ severity: 'error', summary: 'Error', detail: 'Failed to save general info: ' + error.message });
    }
  };
  const saveRiskAssessment = async (accountNum) => {
    try {
   
      console.log("risk assessment");
      console.log(riskAssessmentData);
      console.log(formData.riskAssessmentData);
      const response = await axios.post(
        `http://172.16.182.177:8091/green-project/api/v1/updatedPhase2/${accountNum}`,
        riskAssessmentData,
        { headers: { "Content-Type": "application/json" ,
        } ,
      }
      );
      if (response.status === 200) {
        toast.current.show({ severity: 'success', summary: 'Success', detail: 'Risk assessment saved successfully!' });
      } else {
        throw new Error("Unexpected response from server");
      }
    } catch (error) {
      console.error("Error saving risk assessment:", error);
      toast.current.show({ severity: 'error', summary: 'Error', detail: 'Failed to save risk assessment: ' + error.message });
    }
  };
    const validateForm = () => {
      if (activeIndex === 0) {
        // Validate General Info
        if (!formData.generalInfo.accountNumber || !formData.generalInfo.borrowerName) {
          toast.current.show({ severity: 'warn', summary: 'Validation', detail: 'Please fill in all required fields' });
          return false;
        }
      } else if (activeIndex === 1) {
        // Validate Risk Assessment
        if (!formData.riskAssessmentData?.vulnerability ) {
          toast.current.show({ severity: 'warn', summary: 'Validation', detail: 'Please fill in all required fields for Risk Assessment' });
          return false;
        }
      }
      return true;
    };
   
  const handleChange = async (e, section, field) => {
    const { value } = e.target;
    if (value !== undefined) {
      if (section === 'riskAssessmentData') {
        setFormData({
          ...formData,
          [section]: {
            ...formData[section],
            [field]: value, // Update the specific field
          },
        });
      } else if (section === 'generalInfo') {
        // Updating generalInfo field
        setFormData({
          ...formData,
          [section]: {
            ...formData[section],
            [field]: value, // Update the specific field
          },
        });
        console.log(field);
        if(field === 'susobj'){
          fetchIndicators(value);
        }
      } else if (section === 'sustainability' && field === 'susobj' && value) 
        {
          fetchIndicators(value);
        console.log('Entering sustainability section, field: susobj, with value:', value);
      
        setSelectedSUSObj(value); // Set the selected Susobj
        setIsLoading(true); // Set loading state to true
        try {
          const response = await fetch(`http://172.16.182.177:8091/green-project/api/v1/pickdataSec/${value}`);
          console.log('API Response:', response);
          if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
          }
          const data = await response.json();
          console.log('Fetched Data:', data); // Log the fetched data for inspection
          if (data && data.indicators) {
            setIndicators(data.indicators); // Update the state with the fetched indicators
          } else {
            console.warn('No indicators found for the selected Susobj.');
            alert('No indicators found'); // Show alert if no indicators are found
            setIndicators([]); // Reset the indicators if no data is found
          }
        } catch (error) {
          console.error("Error fetching indicators:", error);
          alert('Error fetching indicators: ' + error.message); // Show error message if fetch fails
        } finally {
          setIsLoading(false); // Set loading state to false once the request is complete
        }
      }
    } else {
      console.warn('Value is undefined');
    }
  };
  const handleStatusChange = (field, value) => {
    setFieldStatus((prevState) => ({
      ...prevState,
      [field]: { status: value, comment: "" },
    }));
  };
  const handleCommentChange = (field, value) => {
    setFieldStatus((prevState) => ({
      ...prevState,
      [field]: { ...prevState[field], comment: value },
    }));
  };
  // Dropdown options
  const statusOptions = [
    { label: "Approve", value: "approve" },
    { label: "Reject", value: "reject" },
  ];
 
  
   const handleAccountNumberChange = async () => {
    const accountNumber = formData.generalInfo.accountNumber; // Get the value from state
 setAccN(formData.generalInfo.accountNumber);
    if (accountNumber) {
      try {
        const response = await axios.post(`http://172.16.182.177:8091/green-project/api/v1/pickdata/${accountNumber}`);
        console.log(response);
        if (response.status === 200) {
        const data =  response.data;
       console.log(data);
        setFormData(prevState => ({
          ...prevState,
          generalInfo: {
            ...prevState.generalInfo,
            borrowerName: data.borrowerName || '',
            branchName: data.branchName || '',
            panNumber: data.panNumber || '',
            cinNumber: data.cinNumber || '',
            schemeCode: data.schemeCode || '',
            activityCode: data.activityCode || '',
            projName: data.projName || '',
          }
        }));
} else {
  throw new Error('Failed to fetch account details');
}
} catch (err) {
toast.current.show({ severity: 'error', summary: 'Error', detail: err.message });
}
} else {
toast.current.show({ severity: 'warn', summary: 'Validation', detail: 'Account Number is required.' });
}
};
  const handleFileChange1 = (e) => {
    const selectedFile = e.target.files[0]; // Get the selected file
    if (selectedFile) {
      setFile(selectedFile); // Set the selected file in the state
    }
  };
  const handleFileChange2 = (e) => {
    const selectedFile = e.target.files[0]; // Get the selected file
    if (selectedFile) {
      setFile(selectedFile); // Set the selected file in the state
    }
  };
  const handleFileChange3 = (e) => {
    const selectedFile = e.target.files[0]; // Get the selected file
    if (selectedFile) {
      setFile(selectedFile); // Set the selected file in the state
    }
  };
  const handleFileChange4 = (e) => {
    const selectedFile = e.target.files[0]; // Get the selected file
    if (selectedFile) {
      setFile(selectedFile); // Set the selected file in the state
    }
  };
  const handleFileUpload1 = async () => {
    console.log('file ',file);
    if (!file) {
      alert('Please select a file to upload.');
      return;
    }
    const formData = new FormData();
    formData.append('EIAfile', file); // Append the file to FormData
    formData.append('fileName', fileName);
    try {
      setIsLoading(true); // Set loading state
      const response = await axios.post(
        `http://172.16.182.177:8091/green-project/api/v1/uploadingEIA?AccountNumber=${AccN}`,
        formData,
        {
          headers: {
            "Content-Type": "multipart/file",
          },
            
          }
      );
      console.log('response',response);
      if (response.status == 200) {
        alert('File uploaded successfully!'); // Alert for successful upload
      } else {
        alert('File upload failed. Please try again.'); // If upload failed
      }
      setIsLoading(false); // Reset loading state
 
    } catch (error) {
      console.error('Error uploading file:', error);
      alert('Error uploading file. Please try again.'); // Alert in case of error
      setIsLoading(false); // Reset loading state
    }
  };

  const handleFileUpload2 = async () => {
    console.log('file ',file);
    if (!file) {
      alert('Please select a file to upload.');
      return;
    }
    const formData = new FormData();
    formData.append('legalVerificationFile', file); // Append the file to FormData
    formData.append('fileName', fileName);
    try {
      setIsLoading(true); // Set loading state
      const response = await axios.post(
        `http://172.16.182.177:8091/green-project/api/v1/uploadingLegal?AccountNumber=${AccN}`,
        formData,
        {
          headers: {
            "Content-Type": "multipart/file",
          },
          }
      );
      console.log('response',response);
      if (response.status == 200) {
        alert('File uploaded successfully!'); // Alert for successful upload
      } else {
        alert('File upload failed. Please try again.'); // If upload failed
      }
      setIsLoading(false); // Reset loading state
 
    } catch (error) {
      console.error('Error uploading file:', error);
      alert('Error uploading file. Please try again.'); // Alert in case of error
      setIsLoading(false); // Reset loading state
    }
  };
  const handleFileUpload3= async () => {
    if (!file) {
      alert('Please select a file to upload.');
      return;
    }
    const formData = new FormData();
    formData.append('financialHealthFile', file);
    formData.append('fileName', fileName); // Append the file to FormData
    try {
      setIsLoading(true); // Set loading state
      const response = await axios.post(
        `http://172.16.182.177:8091/green-project/api/v1/uploadingFinancial?AccountNumber=${AccN}`,
        formData,
        {
          headers: {
            "Content-Type": "multipart/file",
          },
          }
      );
      console.log('response',response);
      if (response.status == 200) {
        alert('File uploaded successfully!'); // Alert for successful upload
      } else {
        alert('File upload failed. Please try again.'); // If upload failed
      }
      setIsLoading(false); // Reset loading state
    } catch (error) {
      console.error('Error uploading file:', error);
      alert('Error uploading file. Please try again.'); // Alert in case of error
      setIsLoading(false); // Reset loading state
    }
  };
  const handleFileUpload4 = async () => {
    if (!file) {
      alert('Please select a file to upload.');
      return;
    }
 
    const formData = new FormData();
    formData.append('ESGfile', file);
    formData.append('fileName', fileName); // Append the file to FormData
    try {
      setIsLoading(true); // Set loading state
      const response = await axios.post(
        `http://172.16.182.177:8091/green-project/api/v1/uploadingESG?AccountNumber=${AccN}`,
        formData,
        {
          headers: {
            "Content-Type": "multipart/file",
          },
           
          }
      );
      console.log('response',response);
      if (response.status == 200) {
        alert('File uploaded successfully!'); // Alert for successful upload
      } else {
        alert('File upload failed. Please try again.'); // If upload failed
      }
      setIsLoading(false); // Reset loading state
 
    } catch (error) {
      console.error('Error uploading file:', error);
      alert('Error uploading file. Please try again.'); // Alert in case of error
      setIsLoading(false); // Reset loading state
    }
  };
useEffect(() => {
  const fetchSUSObjs = async () => {
    const fetchedSUSObjs = [
      'Renewable Energy',
      'Energy Efficiency',
      'Green Buildings',
      'Climate Adaptation',
      'Clean Transportation',
      'Pollution Prevention & Control',
      'Sustainable Water & Waste Mgmt.',
      'Sustainable Management of Living Natural Resources and Land Use',
      'Terrestrial & Aquatic Biodiversity Conservation',
    ];
    setSusobjs(fetchedSUSObjs);
    console.log(selectedSUSObj); // Setting static list of SUSObjs for testing
  };
  fetchSUSObjs();
}, []);
 
  const fetchIndicators = async(value) => {
    console.log('selected vaue :',value);
      setIsLoading(true); // Start loading
      try {
        console.log('selected vaue :',value);
        axios.get(`http://172.16.182.177:8091/green-project/api/v1/pickdataSusObj/${value}`).then(response => {
          console.log(response.data);
          setIndicators(response.data);
      }).catch(error => {
          toast.current.show({ severity: 'error', summary: 'Alert', detail: 'System error ' + error.message, life: 3000 });
              setIsLoading(false);
          console.log(error);
      });
      } catch (error) {
        console.error("Error fetching indicators:", error);
        alert('Error fetching indicators: ' + error.message); // Show error message if fetch fails
      } finally {
        setIsLoading(false); // Stop loading
      }
  };
const handleIndicatorChange = (e) => {
  const { field, newValue,  rowIndex } = e;  // Destructure the event object
 
  setFormData((prevFormData) => {
    const updatedIndicators = [...prevFormData.indicators]; // Create a copy of the indicators array
    updatedIndicators[rowIndex][field] = newValue; // Update the specific field at the correct row
   
    return {
      ...prevFormData,
      indicators: updatedIndicators, // Update the formData with the modified indicators array
    };
  });
};
const handleSUSObjChange = (e) => {
  setSelectedSUSObj(e.target.value); // Update the selected SUSObj
};
  const prevStep = () => {
    setActiveIndex(activeIndex - 1);
  };
  const nextStep = () => {
    setActiveIndex(activeIndex + 1);
  };
 const handleSubmit = async () => {
    if (!validateForm()) return; // Ensure form is validated
    try {
      if (activeIndex === 0) {
        await saveGeneralInfo(formData.generalInfo.accountNumber);
      } else if (activeIndex === 1) {
        await saveRiskAssessment(formData.generalInfo.accountNumber );
      }
       alert("Data saved successfully!");
       nextStep(); // Move to the next step in the form or process
    } catch (error) {
      console.error("Error during form submission:", error);
      toast.current.show({ severity: 'error', summary: 'Error', detail: 'Failed to save data: ' + error.message });
    }
  };
  //Handle input change for the "comment" field
  
  // Function to send updated data to backend
  const handleSubmit1 = () => {
axios.post(`http://172.16.182.177:8091/green-project/api/v1/updatedCmnt${accountNumber}`)
.then((response)=>{
        console.log("Data saved successfully:", response.data);
      })
      .catch((error) =>{
         console.error("Error saving data:", error);
      });
  };
// Reset form data
  const resetForm = () => {
    setFormData({
      generalInfo: {
        accountNumber: '',
        borrowerName: '',
        branchName: '',
        panNumber: '',
        cinNumber: '',
        schemeCode: '',
        activityCode: '',
        description: '',
        projName: '',
        sector: '',
        location: '',
        susobj: '',
        stakeEng: '',
        reportReq: '',
        timeline: '',
        budget: '',
        eiaComments: '',
        eiaFile: null,
        legalVerificationComments: '',
 
        legalVerificationFile:null,
        financialHealthComments: '',
        financialHealthFile:null,
        esgCompliance: '',
        esgFile:null,
      },
      RiskAssesment:
        {
          vulnerability: '',
          vulnerabilityFlag: '',
         carbonintensive: '',
           carbonintFlag: '',
          sealevel:'',
         sealevelFlag: '',
        assetrisk: '',
      assestriskFlag: '',
     supplychain: '',
      supplychainFlag: '',
      shifting: '',
     shiftingFlag: '',
      business:'',
     businessFlag: '',
     climate: '',
       climateFlag: '',
     borroweremission: '',
     borrowersemissionFlag: '',
        },
      indicators: [
        { indicator: '',
           description: '',
            comment: '',
             type: '',
              methodology: ''
            },
      ],
    });
  };
  // Steps configuration
const steps = [
  { label: 'General Information' },
  { label: 'Risk Assessment' },
  { label: 'Project-Specific Indicators' }, // Add this line
];
   const error = (message) => {
    // Handle errors (e.g., displaying an error message)
    console.error(message);
  };
    const handleBack = () => {
      // Example: Go back to the previous page
      window.history.back();
    };
    const handleApprove = (field) => {
        console.log(`${field} approved!`);
      };
      const handleReject = (field) => {
        console.log(`${field} rejected!`);
      };
    return (
        <div className="container1">
            <Header />
               <Sidebar />
                <Toast ref={toast} />
      <div className="step-wrapper">
        <div className="step-navigation">
          {steps.map((step, index) => (
            <div
            type = 'radio'
              key={index}
              className={`step ${activeIndex === index ? 'active' : ''}`}
              onClick={() => setActiveIndex(index)}
            >
              <span className="step-number">{index + 1}</span>
              <span className="step-label">{step.label}</span>
            </div>
          ))}
        </div>
      </div>
               {activeIndex === 0 && (
        <>
          <h2>General Information</h2>
          <div className="container2">
          <div className="form-group1">
        <label htmlFor="accountNumber">
          ACCOUNT NUMBER <span className="required-star">*</span> :
        </label>
        <input
          id="accountNumber"
          type="text"
          value={formData.generalInfo.accountNumber || ""} // Ensure it is controlled
          onChange={(e) => handleChange(e, 'generalInfo', 'accountNumber')}
        />
      </div>
        <Button icon="pi pi-arrow-right" className="NextC" label='Fetch'
        onClick={handleAccountNumberChange}
      />
            {error && <p style={{ color: 'red' }}>{error}</p>}
          </div>
          {/* Business Information */}
          <div className="business-div">
            <h2 className="business-title">General Information (To be provided by Bank)</h2>
            <div className="vertical">
              <div className="vertical1">
                <div className="form-group2">
                  <label htmlFor="borrowerName">Name of The Borrower<span className="required-star">*</span> :</label>
                  <input
                    id="borrowerName"
                    type="text"
                    value={formData.generalInfo.borrowerName}
                    onChange={(e) => handleChange(e, 'generalInfo', 'borrowerName')}
       />
        <Dropdown
          value={fieldStatus["borrowerName"]?.status || ""}
          options={statusOptions}
          onChange={(e) => handleStatusChange("borrowerName", e.value)}
          placeholder="Select"
          className="dropdown-button"
        />
      </div>
 
      {fieldStatus["borrowerName"]?.status === "reject" && (
        <textarea
          className="comment-box"
          placeholder="Enter reason for rejection..."
          value={fieldStatus["borrowerName"]?.comment || ""}
          onChange={(e) => handleCommentChange("borrowerName", e.target.value)}
        />
      )}
 


                <div className="form-group2">
                  <label htmlFor="branchName">Branch<span className="required-star">*</span> :</label>
                  <input
                    id="branchName"
                    type="text"
                    value={formData.generalInfo.branchName}
                    onChange={(e) => handleChange(e, 'generalInfo', 'branchName')}
                  />
                           <Dropdown
          value={fieldStatus["branch"]?.status || ""}
          options={statusOptions}
          onChange={(e) => handleStatusChange("branch", e.value)}
          placeholder="Select"
          className="dropdown-button"
        />
      </div>
 
      {fieldStatus["branch"]?.status === "reject" && (
        <textarea
          className="comment-box"
          placeholder="Enter reason for rejection..."
          value={fieldStatus["branch"]?.comment || ""}
          onChange={(e) => handleCommentChange("branch", e.target.value)}
        />
      )}
                <div className="form-group2">
                  <label htmlFor="panNumber">PAN Number<span className="required-star">*</span> :</label>
                  <input
                    id="panNumber"
                    type="text"
                    value={formData.generalInfo.panNumber}
                    onChange={(e) => handleChange(e, 'generalInfo', 'panNumber')}
                  />
                   
                   <Dropdown
          value={fieldStatus["panNumber"]?.status || ""}
          options={statusOptions}
          onChange={(e) => handleStatusChange("panNumber", e.value)}
          placeholder="Select"
          className="dropdown-button"
        />
      </div>
 
      {fieldStatus["panNumber"]?.status === "reject" && (
        <textarea
          className="comment-box"
          placeholder="Enter reason for rejection..."
          value={fieldStatus["panNumber"]?.comment || ""}
          onChange={(e) => handleCommentChange("panNumber", e.target.value)}
        />
      )}
                <div className="form-group2">
                  <label htmlFor="cinNumber">CIN<span className="required-star">*</span> :</label>
                  <input
                    id="cinNumber"
                    type="text"
                    value={formData.generalInfo.cinNumber}
                    onChange={(e) => handleChange(e, 'generalInfo', 'cinNumber')}
                  />
                  
                  <Dropdown
          value={fieldStatus["cinNumber"]?.status || ""}
          options={statusOptions}
          onChange={(e) => handleStatusChange("cinNumber", e.value)}
          placeholder="Select"
          className="dropdown-button"
        />
      </div>
 
      {fieldStatus["cinNumber"]?.status === "reject" && (
        <textarea
          className="comment-box"
          placeholder="Enter reason for rejection..."
          value={fieldStatus["cinNumber"]?.comment || ""}
          onChange={(e) => handleCommentChange("cinNumber", e.target.value)}
        />
      )}
                </div>
               
               
              <div className="vertical2">
                <div className="form-group2">
                  <label htmlFor="schemeCode">Scheme Code<span className="required-star">*</span> :</label>
                  <input
                    id="schemeCode"
                    type="text"
                    value={formData.generalInfo.schemeCode}
                    onChange={(e) => handleChange(e, 'generalInfo', 'schemeCode')}
                  />
                   
                   <Dropdown
          value={fieldStatus["schemeCode"]?.status || ""}
          options={statusOptions}
          onChange={(e) => handleStatusChange("schemeCode", e.value)}
          placeholder="Select"
          className="dropdown-button"
        />
      </div>
 
      {fieldStatus["schemeCode"]?.status === "reject" && (
        <textarea
          className="comment-box"
          placeholder="Enter reason for rejection..."
          value={fieldStatus["schemeCode"]?.comment || ""}
          onChange={(e) => handleCommentChange("schemeCode", e.target.value)}
        />
      )}
               
                <div className="form-group2">
                  <label htmlFor="activityCode">Activity Code<span className="required-star">*</span> :</label>
                  <input
                    id="activityCode"
                    type="text"
                    value={formData.generalInfo.activityCode}
                    onChange={(e) => handleChange(e, 'generalInfo', 'activityCode')}
                  />
                  <Dropdown
         value={fieldStatus["activityCode"]?.status || ""}
         options={statusOptions}
         onChange={(e) => handleStatusChange("activityCode", e.value)}
         placeholder="Select"
         className="dropdown-button"
       />
     </div>
     
     {fieldStatus["activityCode"]?.status === "reject" && (
        <textarea
          className="comment-box"
          placeholder="Enter reason for rejection..."
          value={fieldStatus["activityCode"]?.comment || ""}
          onChange={(e) => handleCommentChange("activityCode", e.target.value)}
        />
      )}

               
                <div className="form-group2">
  <label htmlFor="description">
    Brief Details of the Project
    <span className="required-star">*</span> :
  </label>
  <textarea
    id="description"
    value={formData.generalInfo.description}
    onChange={(e) => handleChange(e, 'generalInfo', 'description')}
  />
<Dropdown
         value={fieldStatus["description"]?.status || ""}
         options={statusOptions}
         onChange={(e) => handleStatusChange("description", e.value)}
         placeholder="Select"
         className="dropdown-button"
       />
     </div>
     {fieldStatus["description"]?.status === "reject" && (
        <textarea
          className="comment-box"
          placeholder="Enter reason for rejection..."
          value={fieldStatus["description"]?.comment || ""}
          onChange={(e) => handleCommentChange("description", e.target.value)}
        />
      )}

                <div className="form-group2">
                  <label htmlFor="projName">Name of the Project<span className="required-star">*</span> :</label>
                  <input
                  id="projName"
                  type="text"
                  value={formData.generalInfo.projName}
                  onChange={(e) => handleChange(e, 'generalInfo', 'projName')}
            />
            <Dropdown
         value={fieldStatus["projName"]?.status || ""}
         options={statusOptions}
         onChange={(e) => handleStatusChange("projName", e.value)}
         placeholder="Select"
         className="dropdown-button"
       />
     </div>
     {fieldStatus["projName"]?.status === "reject" && (
        <textarea
          className="comment-box"
          placeholder="Enter reason for rejection..."
          value={fieldStatus["projName"]?.comment || ""}
          onChange={(e) => handleCommentChange("projName", e.target.value)}
        />
      )}
</div>

                </div>
            </div>
       
    
   
        
{/* General Information (To be provided by Borrower) */}
<div className='business-div'>
   <h2 className='business-title'>General Information (To be provided by Borrower)</h2>
        <div className='vertical'>
            <div className='vertical1'>
                <div className="form-group2">
                    <label htmlFor="sector">Sector<span className="required-star">*</span> :</label>
                    <input
                    id="sector"
                    type="text"
                    value={formData.generalInfo.sector}
              onChange={(e) => handleChange(e, 'generalInfo', 'sector')}
            />
                </div>
                <div className="form-group2">
                    <label htmlFor="location">Location<span className="required-star">*</span> :</label>
                    <input
                    id="location"
                    type="text"
                    value={formData.generalInfo.location}
                    onChange={(e) => handleChange(e, 'generalInfo', 'location')}
                  />
                </div>
                <div className="form-group2">
                    <label htmlFor="projName">Project Description<span className="required-star">*</span> :</label>
                    <textarea
                    id="description"
                    type="text"
                    value={formData.generalInfo.description}
                    // onChange={(e) => setProjName(e.target.value)}
                    onChange={(e) => handleChange(e, 'generalInfo', 'description')}
            />
                </div>
                <div className="form-group2">
  <label htmlFor="susobj">Sustainability Objectives<span className="required-star">*</span> :</label>
  <select
    id="susobj"
    value={formData.generalInfo.susobj}
    onChange={(e) => handleChange(e, 'generalInfo', 'susobj')}
  >
    <option value="">Select a Type</option>
    {susobjs.map((type, index) => (
      <option key={index} value={type}>
        {type}
      </option>
    ))}
  </select>
</div>
            </div>
            <div className='vertical2'>
                <div className="form-group2">
                    <label htmlFor="stakeEng">Stake Holder Engagement<span className="required-star">*</span> :</label>
                    <input
                    id="stakeEng"
                    type="text"
                    value={formData.generalInfo.stakeEng}
                    onChange={(e) => handleChange(e, 'generalInfo', 'stakeEng')}
                    />
                </div>
                <div className="form-group2">
                    <label htmlFor="reportReq">Reporting Requirements<span className="required-star">*</span> :</label>
                    <input
                    id="reportReq"
                    type="text"
                    value={formData.generalInfo.reportReq}
                    onChange={(e) => handleChange(e, 'generalInfo', 'reportReq')}
            />
                </div>
                <div className="form-group2">
                    <label htmlFor="timeline">Timeline<span className="required-star">*</span> :</label>
                    <input
                    id="timeline"
                    type="text"
                    value={formData.generalInfo.timeline}
                    onChange={(e) => handleChange(e, 'generalInfo', 'timeline')}
                    />
                </div>
                <div className="form-group2">
                    <label htmlFor="budget">Budget<span className="required-star">*</span> :</label>
                    <input
                    id="budget"
                    type="text"
                    value={formData.generalInfo.budget}
                    onChange={(e) => handleChange(e, 'generalInfo', 'budget')}
            />
                </div>
            </div>
        </div>
 </div>
<div className="business-div">
                <h2 className="business-title">Project Evaluation Criteria (To be filled by the Bank)</h2>
                <div className="vertical">
                    <div className="vertical1">
                        <div className="form-group2">
                            <label htmlFor="EIAcomments">EIA Comments<span className="required-star">*</span> :</label>
                            <textarea
                                id="eiacomments"
                                value={formData.generalInfo.eiaComments}
              onChange={(e) => handleChange(e, 'generalInfo', 'eiaComments')}
            />
                        </div>
                        <div className="form-group2">
      <label htmlFor="eiaFile">EIA Upload File<span className="required-star">*</span> :</label>
      <input
        id="eiaFile"
        type="file"
        onChange={handleFileChange1} // Handle file selection
        className="file-input"
      />
        <button type="button" onClick={handleFileUpload1}>
          Upload 
        </button>
      </div>
                        <div className="form-group2">
                            <label htmlFor="legalVerificationComments">Legal Verification Comments<span className="required-star">*</span> :</label>
                            <textarea
                                id="legalVerificationComments"
                                value={formData.generalInfo.legalVerificationComments}
                                onChange={(e) => handleChange(e, 'generalInfo', 'legalVerificationComments')}
                                />
                        </div>
                        <div className="form-group2">
                            <label htmlFor="legalVerificationFile">Legal Verification Upload File<span className="required-star">*</span> :</label>
                            <input
        id="legalVerificationFile"
        type="file"
        onChange={handleFileChange2} // Handle file selection
        className="file-input"
      />
        <button type="button" onClick={handleFileUpload2}>
          Upload
        </button>
                        </div>
                    </div>
                    <div className="vertical2">
                        <div className="form-group2">
                            <label htmlFor="financialHealthComments">Financial Health Comments<span className="required-star">*</span> :</label>
                            <textarea
                                id="financialHealthComments"
                                value={formData.generalInfo.financialHealthComments}
                              //  onChange={(e) => FinancialHealthComments(e.target.value)}
                                onChange={(e) => handleChange(e, 'generalInfo', 'financialHealthComments')}
                                />
                        </div>
                        <div className="form-group2">
                            <label htmlFor="financialHealthFile">Financial Health Upload File<span className="required-star">*</span> :</label>
                            <input
        id="financialHealthFile"
        type="file"
        onChange={handleFileChange3} // Handle file selection
        className="file-input"
      />
        {/* Upload Button */}
        <button type="button" onClick={handleFileUpload3}>
          Upload 
        </button>
                        </div>
                        <div className="form-group2">
                            <label htmlFor="esgCompliance">ESG Compliance Comments<span className="required-star">*</span> :</label>
                            <textarea
                                id="esgCompliance"
                                value={formData.generalInfo.esgCompliance}
                                onChange={(e) => handleChange(e, 'generalInfo', 'esgCompliance')}
                              />
                        </div>
                        <div className="form-group2">
                            <label htmlFor="ESGFile">ESG Upload File<span className="required-star">*</span> :</label>
                            <input
        id="ESGFile"
        type="file"
        onChange={handleFileChange4} // Handle file selection
        className="file-input"
      />
        {/* Upload Button */}
        <button type="button" onClick={handleFileUpload4}>
          Upload 
        </button>
                        </div>
                    </div>
                </div>
                </div>
                </>
                )}
             {activeIndex === 1 && (
            <div className="business-div">
        <h2 className="business-title">Risk Assessment Criteria (To be filled by the Bank)</h2>
        <div className="risk-container">
        <div className="risk-section">
          <h3 className="risk-category">Physical Risk</h3>
          <div className="form-group">
            <label>Location Vulnerability<span className="required-star">*</span> :</label>
            <textarea
             type="text"
             value={formData.riskAssessmentData?.vulnerability || ''}
             onChange={(e) => handleChange(e, 'riskAssessmentData', 'vulnerability',0)}
           />
          </div>
          <div className="form-group">
            <label>Sea-Level Rise (Coastal Properties Only)<span className="required-star">*</span> :</label>
            <textarea
             value={formData.riskAssessmentData?.sealevel || ''}
             onChange={(e) => handleChange(e, 'riskAssessmentData', 'sealevel',0)}
           />
          </div>
          <div className="form-group">
            <label>Supply Chain Disruptions<span className="required-star">*</span> :</label>
            <textarea
             type="text"
             value={formData.riskAssessmentData?.supplychain || ''}
             onChange={(e) => handleChange(e, 'riskAssessmentData', 'supplychain',0)}
           />
          </div>
          </div>
          <div className="risk-section">
          <h3 className="risk-category">Transition Risk</h3>
          <div className="form-group">
          <label>Carbon-Intensive Sector<span className="required-star">*</span> :</label>
<textarea
    type="text"
    value={formData.riskAssessmentData?.carbonintensive || ''}
    onChange={(e) => handleChange(e, 'riskAssessmentData', 'carbonintensive', 0)}
/>
          </div>
          <div className="form-group">
    <label>Stranded Assets Risk<span className="required-star">*</span> :</label>
    <textarea
        type="text"
        value={formData.riskAssessmentData?.assetrisk || ''}
        onChange={(e) => handleChange(e, 'riskAssessmentData', 'assetrisk', 0)}
    />
</div>
<div className="form-group">
<label>shiftingConsumerPreferences<span className="required-star">*</span> :</label>
<textarea
  name="shiftingConsumerPreferences"  // Add a name attribute
  value={formData.riskAssessmentData?.shifting || ''}
  onChange={(e) => handleChange(e, 'riskAssessmentData', 'shifting', 0)}
/>
</div>
        </div>
  </div>
<div className="risk-container">
  <div className="risk-section">
    <h3 className="risk-category">Operational Vulnerabilities</h3>
    <div className="form-group">
      <label>Business Continuity Plans<span className="required-star">*</span> :</label>
      <textarea
        type="text"
        value={formData.riskAssessmentData?.business || ''}
        onChange={(e) => handleChange(e, 'riskAssessmentData', 'business', 0)}
      />
    </div>
    <div className="form-group">
      <label>Climate Resilience Infrastructure<span className="required-star">*</span> :</label>
      <textarea
        type="text"
        value={formData.riskAssessmentData?.climate || ''}
        onChange={(e) => handleChange(e, 'riskAssessmentData', 'climate', 0)}
      />
    </div>
  </div>
  <div className="risk-section">
    <h3 className="risk-category">Emission Data</h3>
    <div className="form-group">
      <label>Borrower’s Emission Footprint<span className="required-star">*</span> :</label>
      <textarea
        type="text"
        value={formData.riskAssessmentData?.borrowersemission || ''}
        onChange={(e) => handleChange(e, 'riskAssessmentData', 'borrowersemission', 0)}
      />
    </div>
  </div>
</div>
</div>
             )}
{activeIndex === 2 && (
  <div className="business-div">
    <h2 className="business-title">Project-Specific Indicators</h2>
    <div className="table-container">
      <div className="maker-datatable">
      <DataTable
        value={indicators} // Ensure formData.indicators is an array
        responsiveLayout="scroll"
        editMode="cell" // Enable cell editing
        onCellEditCommit={handleIndicatorChange} // Triggered when a cell is edited
      >
        <Column
          field="sector"
          header="Sector"
          sortable
          style={{ minWidth: '6rem' }}
          editorDisabled // Make this column non-editable
        />
        <Column
          field="mandatoryIndicator"
          header="Mandatory Indicator"
          sortable
          style={{ minWidth: '6rem' }}
          editorDisabled // Make this column non-editable
        />
        {/* Description - non-editable */}
        <Column
          field="description"
          header="Description"
          sortable
          style={{ minWidth: '6rem' }}
          editorDisabled // Make this column non-editable
        />
        {/* Type - non-editable */}
        <Column
          field="type"
          header="Type"
          sortable
          style={{ minWidth: '6rem' }}
          editorDisabled // Make this column non-editable
        />
      <Column
  field="methodology"
  header="Methodology"
  sortable
  style={{ minWidth: "10rem", whiteSpace: "pre-line" }}
  body={(rowData) => {
    if (!rowData.methodology) return null;
    console.log("Raw Methodology Data:", rowData.methodology); // Debugging
    const formattedMethodology = rowData.methodology
      .split(/\r?\n/) // Handle both Windows (`\r\n`) and Linux (`\n`) line breaks
      .map((point) => point.trim()) // Trim spaces
      .map((point) => point.replace(/^-\s*/, "")) // Remove only the leading "- " if it exists
      .filter((point) => point.length > 0); // Remove empty lines
    return (
      <ul style={{ paddingLeft: "20px", margin: 0, listStyleType: "disc" }}>
        {formattedMethodology.map((point, index) => (
          <li key={index} style={{ marginBottom: "5px", textAlign: "justify" }}>
            {point}
          </li>
        ))}
      </ul>
    );
  }}
  editorDisabled // Make this column non-editable
/>
<Column
  field="comment"
  header="Comment"
  sortable
  style={{ minWidth: '10rem' }} // Increase column width
  body={(rowData,options) => (rowData.mandatoryIndicator?(
    <textarea
      type="text"
       value={rowData.comment||""}
      onChange={(e) => handleCommentChange(e, options.rowIndex, "comment")}
      className="datatable-input"
      style={{
        width: '100%', // Make the input field take full column width
        height: '40px', // Increase input box height
        fontSize: '16px', // Increase text size
        padding: '8px' // Add spacing inside input
      }}
    />
  ):null
  )}
/>
      </DataTable>
    </div>
  </div>
  </div>
)}
    {userRole === "Checker" && (
      <div className="checker-section">
        <h2 className="decision-title">Decision:</h2>
        <div className="radio-group">
          <label className={`radio-label ${approvalStatus === "approve" ? "selected-approve" : ""}`}>
            <input
              type="radio"
              name="decision"
              value="approve"
              checked={approvalStatus === "approve"}
              onChange={() => handleApprovalStatus("approve")}
            />
            Approve
          </label>
          <label className={`radio-label ${approvalStatus === "reject" ? "selected-reject" : ""}`}>
            <input
              type="radio"
              name="decision"
              value="reject"
              checked={approvalStatus === "reject"}
              onChange={() => handleApprovalStatus("reject")}
            />
            Reject
          </label>
        </div>
        {approvalStatus === "reject" && (
          <div className="remarks-section">
            <label htmlFor="remarks">Reason for Rejection:</label>
            <textarea
              id="remarks"
              value={remarks}
              onChange={(e) => setRemarks(e.target.value)}
              className="remarks-input"
              placeholder="Enter rejection reason"
            />
          </div>
        )}
        {userRole === "Maker" && (
          <div className="button-container2">
            {/* <Button label="Submit" onClick={() => alert("Submitted to Checker")} className="submit-button2" /> */}
          </div>
        )}
      </div>
    )}
    <div className='button-container2'>
      {/* <Button label="Save & Next" className="saveNext" onClick={handleSave} /> */}
    </div>
    <Toast ref={toast} />
    <div className="button-container2">
  <Button label="Previous" icon="pi pi-arrow-left" className="saveNext" onClick={prevStep} disabled={activeIndex === 0} />
  {activeIndex < steps.length - 1 ? (
    <>
      <Button label="Save & Next" icon="pi pi-arrow-right" className="saveNext" onClick={handleSubmit} />
      <Button label="Back" className="backButton" onClick={handleBack} />
    </>
  ) : (
    <Button label="Submit" icon="pi pi-check"  className="saveNext" onClick={handleSubmit1} />
  )}
</div>
  </div>
  );
};
export default Middle;
 