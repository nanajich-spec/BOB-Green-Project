import React, { useEffect, useState } from 'react';
import './Sidebar.css';
import axios from 'axios';
import logo1 from './bob_logo.png';
import logo2 from './R-logo.png';
import { useNavigate, useLocation, Link } from 'react-router-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faSignOutAlt } from '@fortawesome/free-solid-svg-icons';
 
const Sidebar = ({onFilterChange}) => {
  const navigate = useNavigate();
  const [storeduser, setStoreduser] = useState(null);
  const [userRole, setUserRole] = useState(null);
  const location = useLocation();
  const [activeLink, setActiveLink] = useState(null);
  const [isUserOpen, setIsUserOpen] = useState(false);
  const [isExistingRecordsOpen, setIsExistingRecordsOpen] = useState(false);
  // const[activeTab,setActiveTab]=useState("");
 
  useEffect(() => {
    const user = JSON.parse(window.sessionStorage.getItem('userDet'));
    console.log("Sidebar data:", user);
    setStoreduser(user);
    if (user) {
      setUserRole(user.userRole);
    }
    console.log("userRole sidebar:", userRole);
  }, []);
 
  const toggleUser = () => {
    setIsUserOpen(!isUserOpen);
  };
 
  const toggleExistingRecords = () => {
    setIsExistingRecordsOpen(!isExistingRecordsOpen); // Toggle the "Existing Records" submenu
  };
 
  useEffect(() => {
    setActiveLink(location.pathname);
  }, [location]); 
 
  const handleLinkClick = (link) => {
    setActiveLink(link);
  };
 
  // Add a check to ensure storeduser is not null before accessing userRole
  if (!storeduser) {
    return null; // Or a loading spinner, or some fallback UI
  }
 
  return (
    <div className="sidebar">
      <div className="logo-container2">
        <img src={logo2} alt="Logo" className="logo2"/>
      </div>
 
      {userRole === 'Maker' && (
        <ul >
          <li>
            <Link
              to="/Maker"
              className={activeLink === "/Maker" ? "active" : ""}
              onClick={() => handleLinkClick("/Maker")}
            >
              New Record
            </Link>
          </li>
          <li>
            <Link
              to="#"
              onClick={toggleExistingRecords}
              className={activeLink === "/existingrecords" ? "active" : ""}
            >
              Existing Records
            </Link>
            {isExistingRecordsOpen && (
              <ul className="submenu">
                <li>
                  <Link
                    to="/Datatable"
                    className={activeLink === "/Datatable" ? "active" : ""}
                    onClick={() => handleLinkClick("/Datatable")}
                  >
                    Return from Checker
                  </Link>
                </li>
                <li>
                  <Link
                    to="/returnfromadmin"
                    className={activeLink === "/returnfromadmin" ? "active" : ""}
                    onClick={() => handleLinkClick("/returnfromadmin")}
                  >
                    Return from Admin
                  </Link>
                </li>
              </ul>
            )}
          </li>
        </ul>
      )}
 
      {userRole === 'Checker' && (
        <ul>
         
          <li>
            <Link
      //      
       to="/Checker"
              // onClick={() =>
              //   setActiveTab("Pending")}// Set the active tab to Pending
                // className={activeTab==="pending"?"active":""}
                className={activeLink === "/Checker" ? "active" : ""}
               //ch1   onClick={() => handleLinkClick("/Checker")} 
               //ch              
               onClick={()=>{
                  handleLinkClick("/Checker");
                  onFilterChange("PENDING");
               }} 
            >
              Pending
            </Link>
          </li>
          <li>
            <Link
            to="/Checker"
            className={activeLink === "/Checker" ? "active" : ""}
            //ch1  onClick={() => handleLinkClick("/Verified")}
            onClick={()=>{
              handleLinkClick("/Checker");
              onFilterChange("VERIFIED");
           }} 
           
            >
              Verified
            </Link>
          </li>
        </ul>
      )}
 
      {userRole === 'Admin' && (
        <ul>
          {/* <li>
            <Link
              to="/admin"
              className={activeLink === "/admin" ? "active" : ""}
              onClick={() => handleLinkClick("/admin")}
            >
              Home
            </Link>
          </li> */}
           <li>
            <Link
      //      
       to="/Admin"
                className={activeLink === "/Admin" ? "active" : ""}
                onClick={() => handleLinkClick("/Admin")}
            >
              Pending
            </Link>
          </li>
          <li>
            <Link
            to="/verifed"
            className={activeLink === "/verified" ? "active" : ""}
            onClick={() => handleLinkClick("/verified")}
           
            >
              Verified
            </Link>
          </li>
          <li>
            <Link onClick={toggleUser}>
              User Management
            </Link>
            {isUserOpen && (
              <ul className="submenu">
                <li>
                  <Link
                    to="/userManagement"
                    className={activeLink === "/userManagement" ? "active" : ""}
                    onClick={() => handleLinkClick("/userManagement")}
                  >
                    Add/Modify
                  </Link>
                </li>
                <li>
                  <Link
                    to="/userManagementV"
                    className={activeLink === "/userManagementV" ? "active" : ""}
                    onClick={() => handleLinkClick("/userManagementV")}
                  >
                    Verify
                  </Link>
                </li>
              </ul>
            )}
          </li>
          <li>
             <Link
              to="/report"
              className={activeLink === "/report" ? "active" : ""}
              onClick={() => handleLinkClick("/report")}
            > 
              Report
            </Link>
          </li>
          <li>
            <Link
              to="/dashboard"
              className={activeLink === "/dashboard" ? "active" : ""}
              onClick={() => handleLinkClick("/dashboard")}
            >
              Dashboard
            </Link>
          </li>
        </ul>
      )}
    </div>
  );
}
 
export default Sidebar;
 










// import React, { useEffect, useState } from 'react';
// import './Sidebar.css';
// import axios from 'axios';
// import logo1 from './bob_logo.png';
// import logo2 from './R-logo.png';
// import { useNavigate, useLocation, Link } from 'react-router-dom';
// import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
// import { faSignOutAlt } from '@fortawesome/free-solid-svg-icons';
 
// const Sidebar = () => {
//   const navigate = useNavigate();
//   const [storeduser, setStoreduser] = useState(null);
//   const [userRole, setUserRole] = useState(null);
//   const location = useLocation();
//   const [activeLink, setActiveLink] = useState(null);
//   const [isUserOpen, setIsUserOpen] = useState(false);
//   const [isExistingRecordsOpen, setIsExistingRecordsOpen] = useState(false);
//   // const[activeTab,setActiveTab]=useState("");
 
//   useEffect(() => {
//     const user = JSON.parse(window.sessionStorage.getItem('userDet'));
//     console.log("Sidebar data:", user);
//     setStoreduser(user);
//     if (user) {
//       setUserRole(user.userRole);
//     }
//     console.log("userRole sidebar:", userRole);
//   }, []);
 
//   const toggleUser = () => {
//     setIsUserOpen(!isUserOpen);
//   };
 
//   const toggleExistingRecords = () => {
//     setIsExistingRecordsOpen(!isExistingRecordsOpen); // Toggle the "Existing Records" submenu
//   };
 
//   useEffect(() => {
//     setActiveLink(location.pathname);
//   }, [location]);
 
//   const handleLinkClick = (link) => {
//     setActiveLink(link);
//   };
 
//   // Add a check to ensure storeduser is not null before accessing userRole
//   if (!storeduser) {
//     return null; // Or a loading spinner, or some fallback UI
//   }
 
//   return (
//     <div className="sidebar">
//       <div className="logo-container2">
//         <img src={logo2} alt="Logo" className="logo2"/>
//       </div>
 
//       {userRole === 'Maker' && (
//         <ul >
//           <li>
//             <Link
//               to="/Maker"
//               className={activeLink === "/Maker" ? "active" : ""}
//               onClick={() => handleLinkClick("/Maker")}
//             >
//               New Record
//             </Link>
//           </li>
//           <li>
//             <Link
//               to="#"
//               onClick={toggleExistingRecords}
//               className={activeLink === "/existingrecords" ? "active" : ""}
//             >
//               Existing Records
//             </Link>
//             {isExistingRecordsOpen && (
//               <ul className="submenu">
//                 <li>
//                   <Link
//                     to="/Datatable"
//                     className={activeLink === "/Datatable" ? "active" : ""}
//                     onClick={() => handleLinkClick("/Datatable")}
//                   >
//                     Return from Checker
//                   </Link>
//                 </li>
//                 <li>
//                   <Link
//                     to="/returnfromadmin"
//                     className={activeLink === "/returnfromadmin" ? "active" : ""}
//                     onClick={() => handleLinkClick("/returnfromadmin")}
//                   >
//                     Return from Admin
//                   </Link>
//                 </li>
//               </ul>
//             )}
//           </li>
//         </ul>
//       )}
 
//       {userRole === 'Checker' && (
//         <ul>
         
//           <li>
//             <Link
//       //       
//        to="/Checker"
//               // onClick={() => 
//               //   setActiveTab("Pending")}// Set the active tab to Pending
//                 // className={activeTab==="pending"?"active":""}
//                 className={activeLink === "/Checker" ? "active" : ""}
//                 onClick={() => handleLinkClick("/Checker")}
//             >
//               Pending
//             </Link>
//           </li>
//           <li>
//             <Link 
//             to="/verifed"
//             className={activeLink === "/verified" ? "active" : ""}
//             onClick={() => handleLinkClick("/verified")}
           
//             >
//               Verified
//             </Link>
//           </li>
//         </ul>
//       )}
 
//       {userRole === 'Admin' && (
//         <ul>
//           <li>
//             <Link
//               to="/admin"
//               className={activeLink === "/admin" ? "active" : ""}
//               onClick={() => handleLinkClick("/admin")}
//             >
//               Home
//             </Link>
//           </li>
//           <li>
//             <Link onClick={toggleUser}>
//               User Management
//             </Link>
//             {isUserOpen && (
//               <ul className="submenu">
//                 <li>
//                   <Link
//                     to="/userManagement"
//                     className={activeLink === "/userManagement" ? "active" : ""}
//                     onClick={() => handleLinkClick("/userManagement")}
//                   >
//                     Add/Modify
//                   </Link>
//                 </li>
//                 <li>
//                   <Link
//                     to="/userManagementV"
//                     className={activeLink === "/userManagementV" ? "active" : ""}
//                     onClick={() => handleLinkClick("/userManagementV")}
//                   >
//                     Verify
//                   </Link>
//                 </li>
//               </ul>
//             )}
//           </li>
//           <li>
//             <Link
//               to="/report"
//               className={activeLink === "/report" ? "active" : ""}
//               onClick={() => handleLinkClick("/report")}
//             >
//               Report
//             </Link>
//           </li>
//           <li>
//             <Link
//               to="/dashboard"
//               className={activeLink === "/dashboard" ? "active" : ""}
//               onClick={() => handleLinkClick("/dashboard")}
//             >
//               Dashboard
//             </Link>
//           </li>
//         </ul>
//       )}
//     </div>
//   );
// }
 
// export default Sidebar;
 




//import React from 'react';
// import React, { useEffect, useState } from 'react';
// import './Sidebar.css';
// import axios from 'axios';
// //import logo from './bank-of-baroda-logo.svg';
// import logo1 from './bob_logo.png';
// import logo2 from './R-logo.png';
// import { useNavigate, useLocation, Link } from 'react-router-dom';
// //import logo from '../imp/logoo.png';
// //import 'font-awesome/css/font-awesome.min.css';
// import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
// import { faSignOutAlt } from '@fortawesome/free-solid-svg-icons';
// import { use } from 'react';


// const Sidebar = () => {

//   const navigate = useNavigate();
//   const [storeduser, setStoreduser] = useState(null);  
//   const [userRole, setUserRole] = useState(null);
//   const location = useLocation();
//   const [activeLink, setActiveLink] = useState(null);
//   const [isUserOpen, setIsUserOpen] = useState(false);
//   const [isExistingRecordsOpen, setIsExistingRecordsOpen] = useState(false);
  

//   useEffect(() => {
//       const user = JSON.parse(window.sessionStorage.getItem('userDet'));
      
//       console.log("Sidebar data:", user);
//       setStoreduser(user);
//       console.log("Sidebar data:", storeduser);
//       setUserRole(user.userRole);
//       //setUserRole(JSON.parse(user.userRole))
//       console.log("userRole sidebar:" , userRole);
//     }, []);
  
   
   
//     const toggleUser = () => {
//       setIsUserOpen(!isUserOpen);
//     };
//     const toggleExistingRecords = () => {
//       setIsExistingRecordsOpen(!isExistingRecordsOpen); // Toggle the "Existing Records" submenu
//     };
   

//     useEffect(() => {
//         setActiveLink(location.pathname);
//       }, [location]);
//     const handleLinkClick = (link) => {
//         setActiveLink(link); 
//     };

//   return (
//     <div className="sidebar">
//                 {/* <h2>Navigation</h2> */}
//                 <div className="logo-container2"> 
//                       <img src={logo2} alt="Logo" className="logo2"/>
//                 </div>
              
                   
//                 {userRole === "Maker" && (
                   
//                 <ul>
//                 <li><Link to="/datasubmission" className={activeLink === "/datasubmission" ? "active" : ""}
//                             onClick={() => handleLinkClick("/datasubmission")}>New Record</Link></li>
                

//                 {/* <li><Link to="/report"className={activeLink === "/report" ? "active" : ""}
//                             onClick={() => handleLinkClick("/report")}>Report</Link></li>   

//                 <li><Link to="/dashboard"className={activeLink === "/dashboard" ? "active" : ""}
//                             onClick={() => handleLinkClick("/dashboard")}>Dashboard</Link></li>             */}
//                       <li>
//             <Link
//               to="#"
//               onClick={toggleExistingRecords}
//               className={activeLink === "/existingrecords" ? "active" : ""}
//             >
//               Existing Records
//             </Link>
//             {isExistingRecordsOpen && (
//               <ul className="submenu">
//                 <li>
//                   <Link
//                     to="/Datatable"
//                     className={activeLink === "/Datatable" ? "active" : ""}
//                     onClick={() => handleLinkClick("/Datatable")}
//                   >
//                     Return from Checker
//                   </Link>
//                 </li>
//                 <li>
//                   <Link
//                     to="/returnfromadmin"
//                     className={activeLink === "/returnfromadmin" ? "active" : ""}
//                     onClick={() => handleLinkClick("/returnfromadmin")}
//                   >
//                     Return from Admin
//                   </Link>
//                 </li>   
                
//                 </ul> 
//                 )}
                

//                 {userRole === 'Checker' && (
                   
//                    <ul>
//                    {/* <li><Link to="/datasubmission" className={activeLink === "/datasubmission" ? "active" : ""}
//                                onClick={() => handleLinkClick("/datasubmission")}>Data Entry</Link></li>
//                     */}
                   
//                    <li><Link to="/verify"className={activeLink === "/verify" ? "active" : ""}
//                                onClick={() => handleLinkClick("/verify")}>Verify</Link></li>
   
//                    {/* <li><Link to="/report"className={activeLink === "/report" ? "active" : ""}
//                                onClick={() => handleLinkClick("/report")}>Report</Link></li>   
   
//                    <li><Link to="/dashboard"className={activeLink === "/dashboard" ? "active" : ""}
//                                onClick={() => handleLinkClick("/dashboard")}>Dashboard</Link></li>             */}
                            
                   
//                    </ul> 
//                 )}

//                 {userRole === 'Admin' && (
                   
//                    <ul>
                   
                   
//                    <li><Link to="/admin"className={activeLink === "/admin" ? "active" : ""}
//                                onClick={() => handleLinkClick("/admin")}>Home</Link></li>

//                 <li>
//                 <Link  onClick={toggleUser}>
//                     User Management
//                 </Link>
//                     {isUserOpen && (
//                     <ul className="submenu">
//                     <li><Link to="/userManagement" className={activeLink === "/userManagement" ? "active" : ""}
//                             onClick={() => handleLinkClick("/userManagement")}>Add/Modify</Link></li>
//                     <li><Link to="/userManagementV" className={activeLink === "/userManagementV" ? "active" : ""}
//                             onClick={() => handleLinkClick("/userManagementV")}>Verify</Link></li>
                    
//                     </ul>
//                 )}
            
//                 </li>   
   
//                    <li><Link to="/report"className={activeLink === "/report" ? "active" : ""}
//                                onClick={() => handleLinkClick("/report")}>Report</Link></li>   
   
//                    <li><Link to="/dashboard"className={activeLink === "/dashboard" ? "active" : ""}
//                                onClick={() => handleLinkClick("/dashboard")}>Dashboard</Link></li>            
                            
                   
//                    </ul> 
//                 )}
//                 </div>
//                 );
//                 }
//                 export default Sidebar;       



























                
//             </div>
//   );
// }

// export default Sidebar;
