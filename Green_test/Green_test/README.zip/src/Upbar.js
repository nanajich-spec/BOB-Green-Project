//import React from 'react';
import React, { useEffect, useState } from 'react';
import './Upbar.css';
import axios from 'axios';
//import logo from './bank-of-baroda-logo.svg';
import logo1 from './bob_logo.png';
import logo2 from './R-logo.png';
import { useNavigate, useLocation, Link } from 'react-router-dom';
//import logo from '../imp/logoo.png';
//import 'font-awesome/css/font-awesome.min.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faSignOutAlt } from '@fortawesome/free-solid-svg-icons';
import { use } from 'react';


const Upbar = () => {

  const navigate = useNavigate();
  const [storeduser, setStoreduser] = useState(null);  
  const [userRole, setUserRole] = useState(null);
  const location = useLocation();
  const [activeLink, setActiveLink] = useState(null);
  const [isUserOpen, setIsUserOpen] = useState(false);
  

  useEffect(() => {
      
    }, []);
  
   
   
    const toggleUser = () => {
      setIsUserOpen(!isUserOpen);
    };

   

    useEffect(() => {
        setActiveLink(location.pathname);
      }, [location]);
    const handleLinkClick = (link) => {
        setActiveLink(link); 
    };

  return (

     <div className="upbar">
    <div className='link-div'>
    <Link to="/datasubmission" className={activeLink === "/datasubmission" ? "active" : ""}
                   onClick={() => handleLinkClick("/datasubmission")}>General Information</Link>
    </div>
    <div className='link-div'>
    <Link to="/datasubmission1" className={activeLink === "/datasubmission1" ? "active" : ""}
                   onClick={() => handleLinkClick("/datasubmission1")}>Project Evaluation Criteria</Link>
    </div>
    <div className='link-div'>
    <Link to="/datasubmission2" className={activeLink === "/datasubmission2" ? "active" : ""}
                   onClick={() => handleLinkClick("/datasubmission2")}>Risk Assessment Framework</Link>
    </div>
    <div className='link-div'>               
    <Link to="/datasubmission3" className={activeLink === "/datasubmission3" ? "active" : ""}
                   onClick={() => handleLinkClick("/datasubmission3")}>Project Specific Indicator</Link>
    </div>

</div>
  );
}

export default Upbar;
