//import React from 'react';
import React, { useEffect, useState } from 'react';
import './Header.css';
import axios from 'axios';
//import logo from './bank-of-baroda-logo.svg';
import logo1 from './bob_logo.png';
import { useNavigate } from 'react-router-dom';
//import logo from '../imp/logoo.png';
//import 'font-awesome/css/font-awesome.min.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faSignOutAlt } from '@fortawesome/free-solid-svg-icons';


const Header = () => {

  const navigate = useNavigate();
  const [user, setUser] = useState(null);  
  const handleLogout = () => {
    localStorage.removeItem('user');
    navigate('/login');
  };


  // useEffect(() => {
  //   const storedUser = window.sessionStorage.getItem('userDet');

  //   console.log("Stored user data:", storedUser);
  //   if (storedUser) {
  //     setUser(JSON.parse(storedUser));  // Set user data if found in session storage
  //   } else {
  //     navigate('/');  // Redirect to login if user is not logged in
  //   }
  // }, [navigate]);
  
  

  return (
    <div className="headerr">
    <header className="header" >
    <h1 className="title2">BOB Green Finance Portal</h1>
    
    {/* <div className="line-container1">
                <div className="line1">
                </div>
              </div>    */}
                    {/* <div className="logo-container1"> 
                      <img src={logo1} alt="Logo" className="logo1"/>
                    </div>  */}
                    
                  
                  {/* <div className="welcome-message">
        
                      {user ? <h2>Welcome: {user.userId} , Role: {user.userRole}!   </h2> : <h2>Loading...</h2>} 
                  </div> */}
                  
                  <div className="end">
                    {/* <button className="logout" onClick={handleLogout}>Logout</button> */}
                    <button className="logout" onClick={handleLogout}>
                          <FontAwesomeIcon icon={faSignOutAlt} />
                    </button>
                  </div>
              

                



         

      

   
    

    </header>
    </div>
  );
}

export default Header;
